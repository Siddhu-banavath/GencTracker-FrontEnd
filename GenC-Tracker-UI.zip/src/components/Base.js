import React from 'react'
import CustomNavBar from './CustomNavBar';
import Footer from './Footer';


const Base = ({ title = "Welcome to GenC-Tracker Application", children }) => {
  return (

    <div className='container-fluid p-0 m-0'>
      
       <CustomNavBar />
       <Footer />
        {children}
        
    </div>
  )
}

export default Base;