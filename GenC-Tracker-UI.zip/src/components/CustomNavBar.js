import React, { useEffect, useState } from 'react';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  NavbarText,
} from 'reactstrap';
import { Navigate, NavLink as ReactLink, useNavigate } from 'react-router-dom';
import { doLogout, getCurrentUserDetail, isLoggedIn } from '../auth';
import userContext from '../context/userContext';



const CustomNavBar = () =>{

    // const userContextData = userContext(userContext)

    let navigate=useNavigate();

    const [isOpen, setIsOpen] = useState(false)

    const [login, setLogin] = useState(false)
    const [userLogin, setUserLogin] = useState(undefined)

    useEffect(()=>{
        setLogin(isLoggedIn())
        setUserLogin(getCurrentUserDetail())

    }, [login])

    const logout = () =>{
        doLogout(()=>{
            setLogin(false)
            // userContextData.setUserLogin({
            //     data : null,
            //     login : false
            // })
            navigate("/home")
            
        })
    }
   
  
  return (
    <div>
        
            <Navbar
                color="dark"
                dark
                expand="md"
                fixed=""
                className="px-5"
            >
                <NavbarBrand  tag={ReactLink} to ="/user/dashboard">
                    GencTracker
                </NavbarBrand>
                <NavbarToggler onClick={()=> setIsOpen(!isOpen)}  />

                <Collapse isOpen={isOpen} navbar>
                    <Nav
                        className="me-auto"
                        navbar
                    >
                        <NavItem>
                            <NavLink tag={ReactLink} to="/home" >
                                ViewForm
                            </NavLink>
                        </NavItem>
    

                        <NavItem>
                            <NavLink tag={ReactLink} to = "/about" >
                               AdminForm
                            </NavLink>
                        </NavItem>
                        

                        <UncontrolledDropdown
                            inNavbar
                            nav
                        >
                            <DropdownToggle
                                caret
                                nav
                            >
                                More
                            </DropdownToggle>
                            <DropdownMenu right>
                                <DropdownItem href="/services">
                                    Contact Us
                                </DropdownItem>
                                <DropdownItem>
                                    Facebook
                                </DropdownItem>
                                <DropdownItem divider />
                                <DropdownItem>
                                    Youtube
                                </DropdownItem>
                                <DropdownItem>
                                    Instagram
                                </DropdownItem>
                                <DropdownItem>
                                    LinkedIn
                                </DropdownItem>
                            </DropdownMenu>
                        </UncontrolledDropdown>
                    </Nav>



                    <Nav navbar>
                        {
                            login && (
                                <>

                                <NavItem>
                                    <NavLink tag={ReactLink} to = "/user/dashboard" >
                                        {userLogin.name}
                                    </NavLink>
                                </NavItem>

                                <NavItem>
                                    <NavLink onClick={logout} tag={ReactLink} to = "/login">
                                        Logout
                                    </NavLink>
                                </NavItem>
                                </>
                         )
                        }
                        {
                            !login &&(
                                <>

                                <NavItem>

                                    <NavLink tag={ReactLink} to ='/login' >
                                        Login
                                    </NavLink>
                                </NavItem> 

                                <NavItem>
                                    <NavLink tag={ReactLink} to ='/' >
                                    Signup
                                    </NavLink>
                                </NavItem> 
                                
                                    
                                </>
                                
                            )
                        }
                    </Nav>
        </Collapse>
      </Navbar>
      
    </div>
  );
}

export default CustomNavBar; 