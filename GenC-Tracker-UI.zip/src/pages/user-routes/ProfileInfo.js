import React from 'react'
import Base from '../../components/Base';

const ProfileInfo = () => {
  return (
    <div>
      <Base>
      <h1> This is Profile info</h1>
      </Base>
    </div>
  )
}

export default ProfileInfo;