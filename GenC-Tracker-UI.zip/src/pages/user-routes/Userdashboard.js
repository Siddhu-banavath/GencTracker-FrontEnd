import React from 'react'
import Base from '../../components/Base';
import { CardImg, CardBody, CardTitle, CardSubtitle, CardText,Button ,Card,CardGroup, Container} from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';
import "./UserDashboard.css"




const Userdashboard = () => {
  return (
    <div>  
        <Base>
        <h1 className='text-center text-success'>Welcome to Admin Dashboard!!!</h1><br />
        {/* <Container> */} <div class = "container">
        <div class = "row">
          <div class="col-sm-8">      
              <Card 
              style={{ width: '25rem' }} >
                <a href="/about">< CardImg 
                alt="Card image cap"
                    src="https://t3.ftcdn.net/jpg/03/48/55/20/360_F_348552050_uSbrANL65DNj21FbaCeswpM33mat1Wll.jpg"
                    top
                    width="100%"
                    
                />  </a>
              </Card> 
              </div>
              </div>

              {/* </Container> */}</div>
              
        </Base>
        
    </div>
  )
}

export default Userdashboard;