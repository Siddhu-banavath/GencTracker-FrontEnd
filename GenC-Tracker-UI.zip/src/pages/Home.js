import Base from '../components/Base'
import React, { useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { myAxios } from '../services/Helper';
import { toast } from "react-toastify";
import { loadAllPosts, deletePostService } from '../services/post-service';
import { Container, Pagination, PaginationItem, PaginationLink } from 'reactstrap';
import axios from 'axios';

const Home = () => {

    let navigate = useNavigate();
    const routeChange = () =>{
    let path = `/home`;
    navigate(path);
  }
  const [users, setUsers] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);

  const recordPerPages = 5;
  const lastIndex = currentPage * recordPerPages;
  const firstIndex = lastIndex - recordPerPages;
  const records = users.slice(firstIndex, lastIndex);
  const npage = Math.ceil(users.length / recordPerPages)
  const numbers = [...Array(npage + 1).keys()].slice(1);
    
    useEffect(() => {
        loadAllPosts().then((data)=>{
          console.log(data)
          setUsers(data)
        }).catch(error=>{
          console.log(error)
        })
    }, []);


    const { associateId } = useParams();

    function deletePost(associateId){
      deletePostService(associateId)
      .then(response=>{
        console.log(response)
        toast.success("Post is Deleted Successfully")
        loadAllPosts();
      }).catch(error=>{
        console.log(error)
        toast.error("error in deleting post")
      })
    }

    // useEffect(() =>{
    //   deleteById(associateId).then((response)=>{
    //     console.log("Id is deleted")
    //     console.log(response)
    //   }).catch(error=>{
    //     console.log(error)
    //   })
    // }, [])

  return (
    <div>
        <Base>
            <div className="container">

            <div className="py-4">

              <table className="table border shadow">

              <thead>

              <tr>
                {/* <th scope="col">ID</th> */}

                <th scope="col">Associate ID</th>

                <th scope="col">Associate Name</th>

                <th scope="col">Project ID</th>

                <th scope="col">Project Name</th>

                <th scope="col">Customer Name</th>

                <th scope="col">Skill</th>

                <th scope="col">Associate City</th>

                <th scope="col">Hcm Name</th>

                <th scope="col">Mentor Name</th>

                <th scope="col">Current Status</th>

                {/* <th scope="col">Last Update</th> */}

                <th scope="col">Action</th>

              </tr>
                </thead>
                <tbody>
                        {records.map((user, i) => (

                            <tr>
                              
                                {/* <td>{user.id}</td> users */}

                                <td>{user.associateId}</td>

                                <td>{user.associateName}</td>

                                <td>{user.projectId}</td>

                                <td>{user.projectName}</td>

                                <td>{user.customerName}</td>

                                <td>{user.skill}</td>

                                <td>{user.associateCity}</td>

                                <td>{user.homeManagerName}</td>

                                <td>{user.mentorName}</td>

                                <td>{user.currentStatus}</td>

                                {/* <td>{user.LastUpdate}</td> */}

                                <div className='container'>
                                  <Link  className="btn btn-outline-primary sm" to={`/viewuser/${user.associateId}`}>View</Link>
                                  <Link className="btn btn-outline-primary sm" to={`/edituser/${user.associateId}`} >Edit</Link>
                                  <button className="btn btn-outline-danger sm" onClick={()=> deletePost(user.associateId)}> Delete</button>  
                                </div>
                                {/* onClick={() => deleteUser(user.id)}
                                 className="btn btn-outline-primary sm-1"
                                 className="btn btn-outline-primary sm-1"
                                 className="btn btn-outline-danger sm-1"*/}
                                 {/* <button className="btn btn-outline-danger sm-2" onClick={() => deleteUser(user.asso_id)}>Delete</button> */}

                            </tr>
                        ))}
                    </tbody>       
                </table>
                <nav>
                  <ul className='pagination'>
                    <li className='page-item'>
                      <a href='/home' className='page-link'
                      onClick={prePage}>Prev</a>
                    </li>
                    {
                      numbers.map((n, i)=>(
                        <li className={`page-item ${currentPage === n ? 'active' : ''}`} key={i}>
                          <a href='#' className='page-link' 
                          onClick={() => changeCpage(n)}>{n}</a>
                        </li>
                      ))
                    }

                    <li className='page-item'>
                      <a href='#' className='page-link'
                      onClick={nextPage}>Next</a>
                    </li>
                  </ul>
                </nav>  
            </div>
           </div> 
            
        </Base>  

    </div>
    
  )
  function prePage(){
    if(currentPage !== firstIndex){
      setCurrentPage(currentPage - 1)
    }
  }

  function changeCpage(associateId){
    setCurrentPage(associateId)
  }

  function nextPage(){
    if(currentPage !== lastIndex){
      setCurrentPage(currentPage + 1)
    }

  }
}

export default Home