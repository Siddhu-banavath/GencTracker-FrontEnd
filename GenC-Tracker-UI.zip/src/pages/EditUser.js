import React, { useEffect, useState } from 'react';
import Base from '../components/Base'
import { CardHeader,Card,  Container, CardBody,Form, FormGroup, Label, Input, Button, Row, Col, FormFeedback } from 'reactstrap';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { loadAllCategories } from '../services/category-services';
import { doCreatePost, updateDetails ,loadAllPostsById} from '../services/post-service';
import { toast } from "react-toastify"
import { getCurrentUserDetail } from '../auth';
import axios from 'axios';


const EditUser = () => {

    let navigate = useNavigate();
    const routeChange = () =>{
    let path = `/home`;
    navigate(path);
    }

    const [categories, setCategories] = useState([])
    const [user, setUser] = useState('')

    const [data, setData] = useState({
        associateId:'',
        associateName:'',
        projectId:'',
        projectName:'',
        customerName:'',
        skill:'',
        associateCity:'',
        homeManagerName:'',
        mentorName:'',
        currentStatus:'',
        LastUpdate:'',
    });

    const {
            associateName,
            projectId,
            projectName,
            customerName,
            skill,
            associateCity,
            homeManagerName,
            mentorName,
            currentStatus 
    } = user
    const handleDetails=()=> {
        setData({
            associateId:'',
            associateName:'',
            projectId:'',
            projectName:'',
            customerName:'',
            skill:'',
            associateCity:'',
            homeManagerName:'',
            mentorName:'',
            currentStatus:'', 
            LastUpdate:'', 
        });
      }
    
    const handleChange=(event, property)=>{
        setData({...data, [property]:event.target.value})    
    }


    const { associateId } = useParams();

            // useEffect(()=>{
            //     loadAllCategories().then((data)=>{
            //     console.log(data)
            //     setCategories(data)
            //     }).catch(error=>{
            //     console.log(error)
            //     })
            // },[]);

            useEffect(() => {
                    loadAllPostsById(associateId).then((response)=>{
                        console.log("updating by id")
                        console.log(associateId)
                        // console.log(data)
                        setData(response)
                        }).catch(error=>{
                        console.log(error)
                        console.log("Not updating by id")
                        })
                    }, []);
    
      
      const createPost= ((event)=>{
        event.preventDefault();
        console.log(data)
        console.log("Update Form submitted")
        // toast.success("Post created")
        
        // if(data.associateId.trim()===''){
        //   toast.error("associateId is required !!")
        //   return;
        // }
    
        // if(data.associateName.trim()===''){
        //   toast.error("associateName is required !!")
        //   return;
        // }
    
        // if(data.projectId.trim()===''){
        //   toast.error("projectId is required !!")
        //   return;
        // }
    
        // if(data.projectName.trim()===''){
        //   toast.error("projectName is required !!")
        //   return;
        // }
    
        // if(data.customerName.trim()===''){
        //   toast.error("customerName is required !!")
        //   return;
        // }
    
        // if(data.skill.trim()===''){
        //   toast.error("skill is required !!")
        //   return;
        // }
    
        // if(data.associateCity.trim()===''){
        //   toast.error("associateCity is required !!")
        //   return;
        // }
    
        // if(data.homeManagerName.trim()===''){
        //   toast.error("homeManagerName is required !!")
        //   return;
        // }
    
        // if(data.mentorName.trim()===''){
        //   toast.error("mentorName is required !!")
        //   return;
        // }
    
        // if(data.currentStatus.trim()===''){
        //   toast.error("currentStatus is required !!")
        //   return;
        // }
    
        // // if(post.LastUpdate.trim()===''){
        // //   toast.error("Time & Date is required !!")
        // //   return;
        // // }

        //submit the form on server
        data['user'] = user.associateId;
        updateDetails(data).then(data=>{
          toast.success("Post Updated")
          console.log(data)
          navigate("/home")
        }).catch((error)=>{
           toast.error("Update error")
          console.log(error)
          navigate("/home")
        })
      })

    

    

  return (
    <div>
        <Base>
        <div class = "edituser">
            <Row className='mt-6'>
                <Col sm={{size:6, offset:3}} >
                <Card color='dark' inverse 
                >
                    {/* style={{width:'35rem'}} */}
                <CardHeader>
                    <h3>GenC Update Form!!!</h3>
                </CardHeader>
                <CardBody>
                    <Form onSubmit={createPost}>
                      
                        <FormGroup>
                            <Label for="associateId">Associate ID</Label>
                            <Input type='text'
                            placeholder='Enter Here' 
                            name='associateId'
                            onChange={(e)=> handleChange(e,'associateId')}
                            value={data.associateId}
                            />
                        </FormGroup>

                        <FormGroup>
                            <Label for="associateName">Associate Name</Label>
                            <Input type='text'
                            placeholder='Enter Here' 
                            name='associateName'
                            onChange={(e)=> handleChange(e,'associateName')}
                            value={data.associateName}
                            />
                        </FormGroup>

                        <FormGroup>
                            <Label for="projectId">Project Id</Label>
                            <Input type='text'
                            placeholder='Enter Here' 
                            name='projectId'
                            onChange={(e)=> handleChange(e,'projectId')}
                            value={data.projectId}
                            />
                        </FormGroup>

                        <FormGroup>
                            <Label for="projectName">Project Name</Label>
                            <Input type='text'
                            placeholder='Enter Here' 
                            name='projectName'
                            onChange={(e)=> handleChange(e,'projectName')}
                            value={data.projectName}
                            />
                        </FormGroup>

                        <FormGroup>
                            <Label for="customerName">Customer Name</Label>
                            <Input type='text'
                            placeholder='Enter Here' 
                            name='customerName'
                            onChange={(e)=> handleChange(e,'customerName')}
                            value={data.customerName}
                            />
                        </FormGroup>

                        <FormGroup>
                            <Label for="skill">Skill</Label>
                            <Input type='select'
                            id="skill"
                            className="rounded-0"
                            name="skill"
                            onChange={(e)=>handleChange(e,'skill')} >
                            <option value="">Enter Skills</option>
                            <option value="TIBCO">TIBCO</option>
                            <option value="Micro service">Micro service</option>
                            <option value="Opensource" >Opensource</option>
                            value={data.skill}
                            </Input>
                        </FormGroup>

                        <FormGroup>
                            <Label for="associateCity">Associate City</Label>
                            <Input type='select'
                            id="associateCity"
                            className="rounded-0"
                            name="associateCity"
                            onChange={(e)=>handleChange(e,'associateCity')} >
                            <option value="/">Enter City</option>
                            <option value="Hyderabad">Hyderabad</option>
                            <option value="Bangalore">Bangalore</option>
                            <option value="Pune" >Pune</option>
                            <option value="Kolkata" >Kolkata</option>
                            <option value="Noida" >Noida</option>
                            <option value="Coimbatore" >Coimbatore</option>
                            <option value="Gurgaon" >Gurgaon</option>
                            <option value="Mumbai" >Mumbai</option>
                            
                            value={data.associateCity}
                            </Input>
                        </FormGroup>

                        <FormGroup>
                            <Label for="homeManagerName">Home Mangager Name</Label>
                            <Input type='text'
                            placeholder='Enter Here' 
                            name='homeManagerName'
                            onChange={(e)=> handleChange(e,'homeManagerName')}
                            value={data.homeManagerName}
                            />
                        </FormGroup>

                        <FormGroup>
                            <Label for="mentorName">Mentor Name</Label>
                            <Input type='text'
                            placeholder='Enter Here' 
                            name='mentorName'
                            onChange={(e)=> handleChange(e,'mentorName')}
                            value={data.mentorName}
                            />
                        </FormGroup>

                        <FormGroup>
                            <Label for="currentStatus">Current Status</Label>
                            <Input type='select'
                            id="currentStatus"
                            placeholder="Enter here"
                            className="rounded-0"
                            name="currentStatus"
                            onChange={(e)=>handleChange(e,'currentStatus')} >
                            <option value="">Enter Status </option>
                            <option value="Batch 10">Batch 11 </option>
                            <option value="Working on POC Project">Working on POC Project </option>
                            <option value="Working Client Project" >Working Client Project</option>
                            </Input>
                        </FormGroup>

                        <Container className='text-center'>
                            <Button type='submit' outline color='primary' to={"/home"}>Update</Button>
                            <Link className="btn btn-outline-warning mx-2" to={"/home"}>CANCEL</Link>
                            
                        </Container>
                    </Form>

                </CardBody>
            </Card>

                </Col>
            </Row>
            </div>
        </Base>
    </div>
  )
}

export default EditUser
















































































// import React, {useEffect, useState} from 'react'
// import Base from '../components/Base'
// import {Link, useNavigate, useParams } from 'react-router-dom'
// import { toast } from "react-toastify";
// import { loadAllPosts, loadAllPostsById, updateDetails } from '../services/post-service'
// import { Container } from 'reactstrap'
// import "./EditUser.css"
// import axios from 'axios'

// const EditUser = () => {


//     let navigate = useNavigate();
//     const routeChange = () =>{
//     let path = `/home`;
//     navigate(path);
//     }


//     const [user, setUser] = useState({
//         associateId:'',
//         associateName:'',
//         projectId:'',
//         projectName:'',
//         customerName:'',
//         skill:'',
//         associateCity:'',
//         homeManagerName:'',
//         mentorName:'',
//         currentStatus:'',
//         LastUpdate:'',
//     })

//     const { 
//         associateName,
//         projectId,
//         projectName,
//         customerName,
//         skill,
//         associateCity,
//         homeManagerName,
//         mentorName,
//         currentStatus,
//         LastUpdate   
//     } = user;

//     const {associateId} = useParams();

//     const onInputChange = (e) => {
//         setUser({ ...user, [e.target.name]: e.target.value });
//         setUser({ ...user, [e.target.name]: e.target.value });
//         setUser({ ...user, [e.target.name]: e.target.value });
//         setUser({ ...user, [e.target.name]: e.target.value });
//         setUser({ ...user, [e.target.name]: e.target.value });
//         setUser({ ...user, [e.target.name]: e.target.value });
//         setUser({ ...user, [e.target.name]: e.target.value });
//         setUser({ ...user, [e.target.name]: e.target.value });
//         setUser({ ...user, [e.target.name]: e.target.value });
//         setUser({ ...user, [e.target.name]: e.target.value });
//         };
 
//         useEffect(() => {
//             loadAllPostsById(associateId).then((response)=>{
//                 console.log("updating by id")
//                 console.log(associateId)
//                 // console.log(data)
//                 setUser(response)
//                 }).catch(error=>{
//                 console.log(error)
//                 console.log("Not updating by id")
//                 })
//             }, []);


//             // useEffect(() => {

//             //     loadUser()
        
//             // }, []);
        
//             // const onSubmit = async (e) => {
        
//             //     e.preventDefault();
        
//             //     await axios.put(`http://localhost:8080/user/${id}`, user)
        
//             //     navigate("/");
//             // };
        
//             // const loadUser = async () => {
        
//             //     const result = await axios.get(`http://localhost:8080/user/${id}`)
        
//             //     setUser(result.data)
        
//             // }

//         // useEffect(() => {
//         //     loadAllPostsById().then((data)=>{
//         //       console.log(data)
//         //       setUser(data)
//         //     }).catch(error=>{
//         //       console.log(error)
//         //     })
//         // }, []);

//         // const updatePost = async (e) => {
//         //         e.preventDefault();
//         //         await axios.put(`http://localhost:8080/api/v1/user/${associateId}`, user)
//         //         navigate("/home");
//         //     };

//         // const updatePost= ((event)=>{
//         //     event.preventDefault();
//         //     console.log("Updating.." + associateId)
//         //     console.log("Updated Form submitted")

//         //     console.log(user.associateId)
//         //     updateDetails(associateId).then((response)=>{
//         //         alert("updated")
//         //         console.log(associateId)
//         //         setUser(response)
//         //         console.log("update error")
//         //     }).catch((error)=>{
//         //         alert("error")
//         //         console.log(error)
//         //         navigate("/home")
//         //     })
//         // })

//         function updatePost(associateId){
//             console.log("Logging into Update " + associateId)


//             updateDetails(user.associateId)
//             .then(response=>{
//               console.log(response)
//               toast.success("Post is updated Successfully")
//               navigate("/home")
//             }).catch(error=>{
//               console.log(error)
//               console.log("update error")
//               toast.error("error in updating post")        
//             })
//         }
            
        
//   return (
//     <div>
//         <Base>
//         <Container>
//         <div class = "edituser">
//                 <div className="container" >
//                     <div className="row">
//                         <div className="col-md-5 offset-md-1 border rounded p-11 mt-1 shadow"  style={{width:'50rem'}}>
//                             <h2 className="text-center m-4">EDIT USER</h2>
//                             <form align="left" onSubmit={(e) => updatePost}>
//                                 <div className="mb-3">
//                                     <label htmlFor="associateId" className="form-label">
//                                         <b>Associate id</b>
//                                     </label>
//                                     <input type={"text"}
//                                     className="form-control"
//                                     placeholder="Enter your Associate_id"
//                                     name="associateId"
//                                     value={associateId}
//                                     onChange={(e) => onInputChange(e)}
//                                 />
//                                 </div>

//                                 <div className="mb-3">
//                                     <label htmlFor="associateName" className="form-label">
//                                         <b>Associate name</b>
//                                     </label>
//                                     <input type={"text"}
//                                     className="form-control"
//                                     placeholder="Enter your Associate_name"
//                                     name="associateName"
//                                     value={associateName}
//                                     onChange={(e) => onInputChange(e)}
//                                 />
//                                 </div>

//                                 <div className="mb-3">
//                                     <label htmlFor="projectId" className="form-label">
//                                         <b>Project ID</b>
//                                     </label>
//                                     <input type={"text"}
//                                     className="form-control"
//                                     placeholder="Enter your Project_id"
//                                     name="projectId"
//                                     value={projectId}
//                                     onChange={(e) => onInputChange(e)}
//                                 />
//                                 </div>

//                                 <div className="mb-3">
//                                     <label htmlFor="projectName" className="form-label">
//                                         <b>Project name</b>
//                                     </label>
//                                     <input type={"text"}
//                                     className="form-control"
//                                     placeholder="Enter your Project_name"
//                                     name="projectName"
//                                     value={projectName}
//                                     onChange={(e) => onInputChange(e)}
//                                 />
//                                 </div>

//                                 <div className="mb-3">
//                                     <label htmlFor="customerName" className="form-label">
//                                         <b>Customer name</b>
//                                     </label>
//                                     <input type={"text"}
//                                     className="form-control"
//                                     placeholder="Enter your Customer Name"
//                                     name="customerName"
//                                     value={customerName}
//                                     onChange={(e) => onInputChange(e)}
//                                 />
//                                 </div>


//                                 <div className="mb-3">
//                                 <label htmlFor="skill" className="form-label">
//                                     <b>Skill</b>
//                                 </label>
//                                 <select className="form-select" name="skill"
//                                     onChange={onInputChange} value={user.skill}>
//                                     <label for="language"></label>
//                                     <option value="">Enter Skill</option>
//                                     <option value="TIBCO">TIBCO</option>
//                                     <option value="Micro service">Micro service</option>
//                                     <option value="Opensource" >Opensource</option></select>
//                             </div>


//                             <div className="mb-3">
//                                 <label htmlFor="associateCity" className="form-label">
//                                     <b>Associate city</b>
//                                 </label>
//                                 <select className="form-select" name="associateCity"
//                                     onChange={onInputChange} value={user.associateCity}>
//                                     <option value="">Enter City</option>
//                                     <option value="Hyderabad">Hyderabad</option>
//                                     <option value="Bangalore">Bangalore</option>
//                                     <option value="Pune" >Pune</option>
//                                     <option value="Kolkata" >Kolkata</option>
//                                     <option value="Noida" >Noida</option>
//                                     <option value="Coimbatore" >Coimbatore</option>
//                                     <option value="PGurgaon" >Gurgaon</option>
//                                     <option value="Mumbai" >Mumbai</option>
//                                 </select>
//                             </div>

//                             <div className="mb-3">
//                                     <label htmlFor="homeManagerName" className="form-label">
//                                         <b>Home Manager name</b>
//                                     </label>
//                                     <input type={"text"}
//                                     className="form-control"
//                                     placeholder="Enter your hcm_name"
//                                     name="homeManagerName"
//                                     value={homeManagerName}
//                                     onChange={(e) => onInputChange(e)}
//                                 />
//                                 </div>

//                                 <div className="mb-3">
//                                     <label htmlFor="mentorName" className="form-label">
//                                         <b>Mentor name</b>
//                                     </label>
//                                     <input type={"text"}
//                                     className="form-control"
//                                     placeholder="Enter your Mentor"
//                                     name="mentorName"
//                                     value={mentorName}
//                                     onChange={(e) => onInputChange(e)}
//                                 />
//                                 </div>

//                                 <div className="mb-3">
//                                 <label htmlFor="currentStatus" className="form-label">
//                                     <b>Current_status</b>
//                                 </label>
//                                 <select className="form-select" name="currentStatus"
//                                     onChange={onInputChange} value={user.currentStatus}>
//                                     <label for="Current Status"></label>
//                                     <option value=""> Enter Status</option>
//                                     <option value="Batch 10">Batch 11 </option>
//                                     <option value="Working on POC Project">Working on POC Project </option>
//                                     <option value="Working Client Project" >Working Client Project</option>
//                                 </select>   
//                             </div>

//                             {/* <div className="mb-3">
//                                     <label htmlFor="LastUpdate" className="form-label">
//                                         <b>Last Update</b>
//                                     </label>
//                                     <input type={"datetime-local"}
//                                     className="form-control"
//                                     placeholder="Enter your Last Updated Date & Time"
//                                     name="LastUpdate"
//                                     value={LastUpdate}
//                                     onChange={(e) => onInputChange(e)}
//                                 />
//                                 </div> */}
//                             <div className='mb-5'>
//                             <button type="submit" className="btn btn-outline-primary"  onClick={()=>updatePost(user.associateId)} to={"/home"}>SUBMIT</button>
//                             <Link className="btn btn-outline-danger mx-2" to={"/home"}>CANCEL</Link>
//                             </div>
//                             </form>
//                         </div>
//                         </div>
//                     </div>
//                 </div>
//             </Container>  
//         </Base>
//     </div>
//   )
// }
// export default EditUser;