import React, { useEffect, useState } from 'react';
import Base from '../components/Base';
import { CardHeader,Card,  Container, CardBody,Form, FormGroup, Label, Input, Button, Row, Col, FormFeedback } from 'reactstrap';
import { signUp } from '../services/user-service';
import { toast } from "react-toastify";
import "./SignUp.css";
import Validation from './SignUpValidation';
import { GoogleLogin } from '@react-oauth/google';


const SignUp = () => {
    
    const [data, setData] = useState({
        name:'',
        email:'',
        password:''
    });

    const [error, setError] = useState({
        errors: {},
        isError:false,
    })

    // useEffect(()=>{
    //     console.log(data);
    // },[data])
        

    // Handle Change
    const handleChange=(event, property)=>{
        //dynamic setting values
        setData({...data, [property]:event.target.value})
        
        // console.log("name changed")
        // console.log(event.target.value)
    }

    //resting the form
    const resetData=()=>{
        setData({
            name:'',
            email:'',
            password:'',

        })
    }

    // submit the form
    const submitForm=(event)=>{
        event.preventDefault();
        // setError(Validation(data));
        // if(error.isError){
        //     // toast.error("Form data is invalid, correct all details then submit");
        //     // toast.error("Invalid Details or Email Already exist please try another!!")
        //     setError({...error, isError:false})
        //     return;
        // }
        if(data.name.trim()===''){
            toast.error("name is required !!")
            return;
          }

          if(data.email.trim()===''){
            toast.error("email is required !!")
            return;
          }

          if(data.password.trim()===''){
            toast.error("password is required !!")
            return;
          }
        console.log(data);
        
        // data validate

        //call server api for sending data
        signUp(data).then((resp) => {
            console.log(resp);
            console.log("success log");
            toast.success("User is registered successfully !!" );  // resp.id
            setData({
                name:'',
                email:'',
                password:'', 
            })     
        }).catch((error) => {
        console.log(error);
        console.log("Error log");

        // handle errors in proper way
        setError({
            errors:error,
            isError:true
        });
      });
  };


  return (
    <div>
        <Base>

        <div class = "singup">
            <Row className='mt-4'>
                  
                <Col sm={{size:6, offset:3}} >

                <Card color='dark' inverse 
                >
                    {/* style={{width:'35rem'}} */}
                <CardHeader>
                    <h3>GenC Register Form!!!</h3>
                </CardHeader>
                <CardBody>
                    <Form onSubmit={submitForm}>
                        {/* Name Field*/}
                        <FormGroup>
                            <Label for="name">Enter Name</Label>
                            <Input type='text'
                            placeholder='Enter here' 
                            id='name'
                            onChange={(e)=> handleChange(e,'name')}
                            value={data.name}
                            // {error.name && <p style={{color: "red"}}>{error.name}</p>}
                            invalid={error.errors?.response?.data?.name ? true:false }
                            />

                            <FormFeedback>
                                { error.errors?.response?.data?.name };
                            </FormFeedback>

                        </FormGroup>

                        

                        {/* email Field*/}
                        <FormGroup>
                            <Label for="email">Enter Email</Label>
                            <Input type='email'
                            placeholder='Enter here'
                            id='email'
                            onChange={(e)=> handleChange(e,'email')}
                            value={data.email}
                            // {error.email && <p style={{color: "red"}}>{error.email}</p>}
                            invalid={error.errors?.response?.data?.email ? true:false }
                            />

                        <FormFeedback>
                            { error.errors?.response?.data?.email };
                        </FormFeedback>
                        </FormGroup>

                        {/* password Field*/}
                        <FormGroup>
                            <Label for="password">Enter Password</Label>
                            <Input type='password'
                            placeholder='Enter here'
                            id='password'
                            onChange={(e)=> handleChange(e,'password')}
                            value={data.password}
                            // {error.password && <p style={{color: "red"}}>{error.password}</p>}
                            invalid={error.errors?.response?.data?.password ? true:false }
                            />

                        <FormFeedback>
                            { error.errors?.response?.data?.password };
                        </FormFeedback>
                        </FormGroup>

                        <Container className='text-center'>
                            <Button outline color='light'>Register</Button>
                            <Button onClick={resetData} outline color='light' type='reset' className='ms-2'>Reset</Button>
                        </Container>
                    </Form>

                </CardBody>
            </Card>

                </Col>
            </Row>
            </div>

        
        </Base> 
    </div>
  )
}

export default SignUp;