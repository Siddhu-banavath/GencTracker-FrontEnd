import React, { useState, useEffect, useRef } from 'react'
import { Card, CardBody, Container,Form, Input, Label, Button} from 'reactstrap'
import { Link, useNavigate } from "react-router-dom";
import { loadAllCategories } from '../services/category-services';
import { toast } from "react-toastify"
import JoditEditor from 'jodit-react';
import {doCreatePost } from '../services/post-service';
import Base from '../components/Base'
import { getCurrentUserDetail } from '../auth';
// import { Scrollbars } from 'react-custom-scrollbars';

const About = () => {

 let navigate = useNavigate();
 const routeChange = () =>{
  let path = `/home`;
  navigate(path);
 }

  const editor = useRef(null)
  const [content , setContent] = useState('')
  const [categories, setCategories] = useState([])
  const [user, setUser] = useState('')

   const [post, setPost] = useState({
        associateId:'',
        associateName:'',
        projectId:'',
        projectName:'',
        customerName:'',
        skill:'',
        associateCity:'',
        homeManagerName:'',
        mentorName:'',
        currentStatus:'',
        LastUpdate:'',
  });

  const handleDetails=()=> {
    setPost({
        associateId:'',
        associateName:'',
        projectId:'',
        projectName:'',
        customerName:'',
        skill:'',
        associateCity:'',
        homeManagerName:'',
        mentorName:'',
        currentStatus:'', 
        LastUpdate:'', 
    });
  }

  useEffect(()=>{
    setUser(getCurrentUserDetail())
    loadAllCategories().then((data)=>{
      console.log(data)
      setCategories(data)
    }).catch(error=>{
      console.log(error)
    })
  },[]);


  //field changed function
  const fieldChanged=((event)=>{
    setPost({...post,[event.target.name]:event.target.value})
    setPost({...post,[event.target.name]:event.target.value})
    setPost({...post,[event.target.name]:event.target.value})
    setPost({...post,[event.target.name]:event.target.value})
    setPost({...post,[event.target.name]:event.target.value})
    setPost({...post,[event.target.name]:event.target.value})
    setPost({...post,[event.target.name]:event.target.value})
    setPost({...post,[event.target.name]:event.target.value})
    setPost({...post,[event.target.name]:event.target.value})
    setPost({...post,[event.target.name]:event.target.value})
    setPost({...post,[event.target.name]:event.target.value})
  })


  // const contentFieldChanged=(data)=>{
  //   setPost({...post,'content':data})
  // }
 
  // creating post
  const createPost= ((event)=>{
    event.preventDefault();
    console.log(post)
    console.log("Form submitted")
    // toast.success("Post created")
    
    if(post.associateId.trim()===''){
      toast.error("associateId is required !!")
      return;
    }

    if(post.associateName.trim()===''){
      toast.error("associateName is required !!")
      return;
    }

    if(post.projectId.trim()===''){
      toast.error("projectId is required !!")
      return;
    }

    if(post.projectName.trim()===''){
      toast.error("projectName is required !!")
      return;
    }

    if(post.customerName.trim()===''){
      toast.error("customerName is required !!")
      return;
    }

    if(post.skill.trim()===''){
      toast.error("skill is required !!")
      return;
    }

    if(post.associateCity.trim()===''){
      toast.error("associateCity is required !!")
      return;
    }

    if(post.homeManagerName.trim()===''){
      toast.error("homeManagerName is required !!")
      return;
    }

    if(post.mentorName.trim()===''){
      toast.error("mentorName is required !!")
      return;
    }

    if(post.currentStatus.trim()===''){
      toast.error("currentStatus is required !!")
      return;
    }

    // if(post.LastUpdate.trim()===''){
    //   toast.error("Time & Date is required !!")
    //   return;
    // }

    //submit the form on server
    post['user'] = user.associateId;
    doCreatePost(post).then(data=>{
      toast.success("Post created")
      console.log(post)
      navigate("/home")
    }).catch((error)=>{
       alert("error")
      console.log(error)
      navigate("/home")
    })
  })

  return (
    <div className='wrapper'> 
      <Base>
      <div className='container'>
      <Container>
      
        <Card className='shadow-sm border-0 mt-1'
        style={{width:'50rem',height: '60rem'}}>
           
          <CardBody>
          {/* <Scrollbars style={{ width: 500, height: 300 }}> */}
            {/* {JSON.stringify(post)} */}
           
            <h3 className='text-center'>Enter Associate Details</h3>
            <Form onSubmit={createPost}>
              <div className='my-3'> 
              <Label for="associateId" >Associate ID</Label>
                <Input type='text'
                id="associateId"
                placeholder="Enter here"
                className="rounded-0"
                name="associateId"
                onChange={fieldChanged}
                 />
              </div>

              <div className='my-3'> 
              <Label for="associateName" >Associate Name</Label>
                <Input type='text'
                id="associateName"
                placeholder="Enter here"
                className="rounded-0"
                name="associateName"
                onChange={fieldChanged} />
              </div>

              <div className='my-3'> 
              <Label for="projectId" >Project ID</Label>
                <Input type='text'
                id="projectId"
                placeholder="Enter here"
                className="rounded-0"
                name="projectId"
                onChange={fieldChanged} />
              </div>

              <div className='my-3'> 
              <Label for="projectName" >Project Name</Label>
                <Input type='text'
                id="projectName"
                placeholder="Enter here"
                className="rounded-0"
                name="projectName"
                onChange={fieldChanged} />
              </div>

              <div className='my-3'> 
              <Label for="customerName" >Customer Name</Label>
                <Input type='text'
                id="customerName"
                placeholder="Enter here"
                className="rounded-0"
                name="customerName"
                onChange={fieldChanged} />
              </div>

              <div className='my-3'> 
              <Label for="skill" >Skill</Label>
                <Input type='select'
                id="skill"
                className="rounded-0"
                name="skill"
                onChange={fieldChanged} >
                  {/* {
                    categories.map((skill)=>(
                      <option key={skill.skill}>
                        {skill.skill} 
                      </option>
                    )) 
                  } */}
                  <option value="">Enter Skills</option>
                  <option value="TIBCO">TIBCO</option>
                  <option value="Micro service">Micro service</option>
                  <option value="Opensource" >Opensource</option>
                </Input>
              </div>

              <div className='my-3'> 
              <Label for="associateCity" >Associate City</Label>
                <Input type='select'
                id="associateCity"
                className="rounded-0"
                name="associateCity"
                onChange={fieldChanged} >
                  <option value="/">Enter City</option>
                  <option value="Hyderabad">Hyderabad</option>
                  <option value="Bangalore">Bangalore</option>
                  <option value="Pune" >Pune</option>
                  <option value="Kolkata" >Kolkata</option>
                  <option value="Noida" >Noida</option>
                  <option value="Coimbatore" >Coimbatore</option>
                  <option value="Gurgaon" >Gurgaon</option>
                  <option value="Mumbai" >Mumbai</option>
                  
                </Input>
              </div>

              <div className='my-3'> 
              <Label for="homeManagerName" >Home Manager Name</Label>
                <Input type='text'
                id="homeManagerName"
                placeholder="Enter here"
                className="rounded-0"
                name="homeManagerName"
                onChange={fieldChanged} />
              </div>

              <div className='my-3'> 
              <Label for="mentorName" >Mentor Name</Label>
                <Input type='text'
                id="mentorName"
                placeholder="Enter here"
                className="rounded-0"
                name="mentorName"
                onChange={fieldChanged} />
              </div>

              <div className='my-3'> 
              <Label for="currentStatus" >Current Status</Label>
                <Input type='select'
                id="currentStatus"
                placeholder="Enter here"
                className="rounded-0"
                name="currentStatus"
                onChange={fieldChanged} 
                 >
                  <option value="">Enter Status </option>
                  <option value="Batch 10">Batch 11 </option>
                  <option value="Working on POC Project">Working on POC Project </option>
                  <option value="Working Client Project" >Working Client Project</option>
                </Input>
              </div>

              {/* <div className='my-3'> 
              <Label for="LastUpdate" >LastUpdate</Label>
                <Input type='datetime-local'
                id="LastUpdate"
                placeholder="Enter here"
                className="rounded-0"
                name="LastUpdate"
                onChange={fieldChanged} />
              </div> */}

              <Container className='text-center'>
              <Button type='submit' outline color='primary' to={"/home"} >Submit</Button>
              <Link className="btn btn-outline-warning mx-2" to={"/home"}>CANCEL</Link>
              <Button onClick={handleDetails} outline color='secondary' type='reset' className='ms-2'>Reset Content</Button>
              </Container>
            </Form>   
            {/* onClick={handleDetails} */}
            {/* </Scrollbars> */}
          </CardBody>
        </Card>
        
      </Container>
      </div>
      
      </Base>
      </div>
  )
}

export default About; 
