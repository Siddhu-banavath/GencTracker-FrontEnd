import React, { useEffect, useState } from 'react';
import Base from '../components/Base'
import { loadAllPostsById } from '../services/post-service';
import { Link, useParams } from 'react-router-dom';
import { myAxios } from '../services/Helper';
import userContext from '../context/userContext';


const ViewUser = () => {

    const [user, setUsers] = useState({
        associateId:'',
        associateName:'',
        projectId:'',
        projectName:'',
        customerName:'',
        skill:'',
        associateCity:'',
        homeManagerName:'',
        mentorName:'',
        currentStatus:'',
        LastUpdate:'',
        });

        const { associateId } = useParams();

       

        useEffect(() => {
            loadAllPostsById(associateId).then((response)=>{
                console.log("Entering by id")
                console.log(associateId)
                // console.log(data)
                setUsers(response)
                }).catch(error=>{
                console.log(error)
                console.log("getting by id")
                })
            }, []);


  return (
    <div>
        <Base>
        <div className="container">
            <div className="row">
                <div className="col-md-6 offset-md-1 border rounded p-10 mt-2 shadow" style={{width:'40rem'}}>
                    <h2 className="text-center m-4">USER DETAILS</h2>
                    <div className="card">
                        <div className="card-header">
                            {/* <b> user id</b> : {user.id} */}
                            <ul className="list-group  list-group-flush">

                                <li className="list-group-item">

                                    <b>Associate Id :</b>
                                    {user.associateId}
                                    </li>

                                <li className="list-group-item">
                                    <b>Associate Name :</b>
                                    {user.associateName}
                                </li>

                                <li className="list-group-item">

                                    <b>Project Id : </b>

                                    {user.projectId}

                                </li>

                                <li className="list-group-item">

                                    <b>Projecte Name : </b>

                                    {user.projectName}

                                </li>

                                <li className="list-group-item">

                                    <b>Customer name : </b>

                                    {user.customerName}

                                </li>

                                <li className="list-group-item">

                                    <b>Skill : </b>

                                    {user.skill}

                                </li>

                                <li className="list-group-item">

                                    <b>Associate city : </b>

                                    {user.associateCity}

                                </li>

                                <li className="list-group-item">

                                    <b>Home manager Name : </b>

                                    {user.homeManagerName}

                                </li>

                                <li className="list-group-item">

                                    <b>Mentor name : </b>

                                    {user.mentorName}

                                </li>

                                <li className="list-group-item">

                                    <b> Current status : </b>

                                    {user.currentStatus}

                                </li>

                                {/* <li className="list-group-item">

                                    <b>Last Updated : </b>

                                    {user.LastUpdate}

                                </li> */}

                            </ul>

                        </div>

                    </div>

                    <Link className="btn btn-primary my-2" to={"/home"}>Back to Home</Link>

                </div>

            </div>

        </div>               
        
        </Base>
    </div>

  )
}

export default ViewUser;