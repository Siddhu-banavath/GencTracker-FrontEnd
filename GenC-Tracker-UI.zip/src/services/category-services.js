import { myAxios } from "./Helper";

export const loadAllCategories=()=>{
    return myAxios.get('/user/get').then(response=>{return response.data})
}

// export const loadAllCategoriesById=()=>{
//     return myAxios.get('/user/userIds').then(response=>{return response.data})
// }

