import { myAxios } from "./Helper";

export const signUp=(userLogin) => {
  return myAxios
  .post('/auth/register', userLogin)
  .then((response)=> response.data)
};


export const userLogin = (loginDetail) => {
  return myAxios
    .post("/auth/login", loginDetail)
    .then((response) => response.data);
};

// export const assoDetails = (user) =>{
//   return myAxios
//   .post("/user/", user)
//   .then((response) => response.data);
// };


// export const getUser = (userId) => {
//   return myAxios.get(`/users/${userId}`).then((resp) => resp.data);
// }; 