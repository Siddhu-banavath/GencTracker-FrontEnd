import { privateAxios } from "./Helper"
import { myAxios } from "./Helper";

export const doCreatePost=(postData)=>{
    console.log('print data')
   // console.log(postData)
    return privateAxios
    .post("/user/", postData)
    .then((response)=> response.data)
};


export const loadAllPosts=()=>{
    console.log("getting the details")
    return myAxios
    .get("/user/get")
    .then((response)=>response.data)
};

export const loadAllPostsById=(associateId)=>{
    console.log("getting details by id")
    console.log(associateId)
    return myAxios 
    .get(`/user/${associateId}`)
    .then((response)=>response.data)
};


export function updateDetails(postData){
    console.log("updating details updating details")
    console.log(postData.associateId)
    return privateAxios
    .put(`/user/${postData.associateId}`, postData)
    .then((response)=>response.data)
}

// export function updateDetails(associateId){
//     console.log("updating details by id")
//     return privateAxios.put(`/user/${associateId}`)
//     .then((response)=>response.data)
// };


export function deletePostService(associateId){
    return privateAxios.delete(`/user/${associateId}`)
    .then((response)=> response.data);
}



 